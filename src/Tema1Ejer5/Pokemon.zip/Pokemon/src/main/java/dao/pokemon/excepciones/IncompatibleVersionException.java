package dao.pokemon.excepciones;

public class IncompatibleVersionException extends Exception {
}

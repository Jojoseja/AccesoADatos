package dao.pokemon.excepciones;

public class DataIntegrityException extends Exception {
}

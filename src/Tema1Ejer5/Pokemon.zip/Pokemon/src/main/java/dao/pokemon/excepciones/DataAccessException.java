package dao.pokemon.excepciones;

public class DataAccessException extends Exception {
}
